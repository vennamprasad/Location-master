# Loca 
Android App for sharing location with friends from contacts using Firebase realtime database and google maps API

### Screenshots of a sample Android app

<p align="center">
<img src="https://github.com/Shailesh351/Loca/raw/master/demo-1.jpg" height = "480" width="270"> <img src="https://github.com/Shailesh351/Loca/raw/master/demo-2.jpg" height = "480" width="270"> <img src="https://github.com/Shailesh351/Loca/raw/master/demo-3.jpg" height = "480" width="270"> <img src="https://github.com/Shailesh351/Loca/raw/master/demo-4.jpg" height = "480" width="270">
</p>
